import React from 'react';
const Login = () => <div>Login Page (Add form here)</div>;
export default Login;