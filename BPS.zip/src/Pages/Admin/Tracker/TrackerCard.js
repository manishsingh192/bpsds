import React from 'react'

const TrackerCard = () => {
    return (
        <div>
            Tracker Card
        </div>
    )
}

export default TrackerCard
