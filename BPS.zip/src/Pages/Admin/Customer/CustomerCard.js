import React from 'react'

const CustomerCard = () => {
    return (
        <div>
            Customer Card
        </div>
    )
}

export default CustomerCard
