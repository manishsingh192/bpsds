import React from 'react'

const ExpenseCard = () => {
    return (
        <div>
            Expense Card
        </div>
    )
}

export default ExpenseCard
