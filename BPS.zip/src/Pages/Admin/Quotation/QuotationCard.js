import React from 'react'

const QuotationCard = () => {
    return (
        <div>
            Quotation Card
        </div>
    )
}

export default QuotationCard
