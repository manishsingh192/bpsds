import React from 'react'

const DeliveryCard = () => {
    return (
        <div>
            Delivery Card
        </div>
    )
}

export default DeliveryCard
