import React from 'react'

const VehicleCard = () => {
    return (
        <div>
            Vehicle Card
        </div>
    )
}

export default VehicleCard
