import React from 'react'

const ContactCard = () => {
    return (
        <div>
            Contact Card
        </div>
    )
}

export default ContactCard
