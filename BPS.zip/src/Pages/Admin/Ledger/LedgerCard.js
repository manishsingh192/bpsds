import React from 'react'

const LedgerCard = () => {
    return (
        <div>
            Ledger Card
        </div>
    )
}

export default LedgerCard
