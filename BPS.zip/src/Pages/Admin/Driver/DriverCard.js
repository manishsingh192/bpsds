import React from 'react'

const DriverCard = () => {
    return (
        <div>
            Driver Card
        </div>
    )
}

export default DriverCard
