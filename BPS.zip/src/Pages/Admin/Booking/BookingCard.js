import React from 'react'

const BookingCard = () => {
    return (
        <div>
            Booking Crad
        </div>
    )
}

export default BookingCard
