import React from 'react';
import Login from '../Pages/Login';

const PublicRoute = () => <Login />;
export default PublicRoute;
